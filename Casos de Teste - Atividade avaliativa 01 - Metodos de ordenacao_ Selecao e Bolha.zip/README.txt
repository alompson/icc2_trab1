Arquivo zip gerado em: 07/09/2020 23:21:19 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Atividade avaliativa 01 - Métodos de ordenação: Seleção e Bolha